package com.test.mylupusproject;

import android.os.StrictMode;
import android.util.Log;

import java.sql.*;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

public class DbConnectionHelper {
    String uname, pass, ip, port, database, connectionName;
    private HikariDataSource connectionPool;

    public Connection connectionclass()
    {
        ip = "34.16.137.138";
        database = "lupusdb";
        connectionName = "mylupusproject:us-west4:lupus1";
        uname = "sqlserver";
        pass = "SQLP@55w0rd";
//        port = "1433";

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        Connection connection = null;
        String ConnectionURL = null;

        HikariConfig config = new HikariConfig();

        try {
            //Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            //config.setDataSourceClassName("com.microsoft.sqlserver.jdbc.SQLServerDataSource");
            ConnectionURL = "jdbc:sqlserver://;databaseName=" + database + ";socketFactoryClass=com.google.cloud.sql.sqlserver.SocketFactory;socketFactoryConstructorArg=" + connectionName
                            + ";user=" + uname + ";password=" + pass;

            config.setDriverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            config.setJdbcUrl(ConnectionURL);
            //config.setDataSourceClassName("net.sourceforge.jtds.jdbcx.JtdsDataSource");
            //config.setUsername(uname);
            //config.setPassword(pass);
            //config.addDataSourceProperty("databaseName", database);
            //config.addDataSourceProperty("socketFactoryClass", "com.google.cloud.sql.sqlserver.SocketFactory");
            //config.addDataSourceProperty("socketFactoryConstructorArg", connectionName);
            //config.addDataSourceProperty("encrypt", "false");
            config.setConnectionTimeout(10000); // 10s
            connectionPool = new HikariDataSource(config);

            //Class.forName("net.sourceforge.jtds.jdbc.Driver");
            //ConnectionURL = "jdbc:jtds:sqlserver://" + ip + ":" + port + "/" + database;

//            connection = DriverManager.getConnection(ConnectionURL);
            connection = connectionPool.getConnection();
        } catch (Exception ex) {
            Log.e( "Error ", ex.getMessage());
        }
        return connection;

    }
}
