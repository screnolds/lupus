package com.test.mylupusproject;

import android.os.AsyncTask;
import android.util.Log;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class HttpGetTask extends AsyncTask<Void, Void, String> {
    private String url;
    private TextView tv;

    public HttpGetTask(String url, TextView tv) {
        this.url = url;
        this.tv = tv;
    }
    @Override
    protected String doInBackground(Void... params) {
        HttpURLConnection urlConnection = null;
        StringBuilder res = new StringBuilder();
        try {
            URL url = new URL(this.url);
            urlConnection = (HttpURLConnection) url.openConnection();

            int code = urlConnection.getResponseCode();
            if (code !=  200) {
                throw new IOException("Invalid response from server: " + code);
            }

            BufferedReader rd = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
            String line;
            while ((line = rd.readLine()) != null) {
                res.append(line);
            }
            rd.close();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
        }

        return res.toString();
    }

    protected void onPostExecute(String res) {
        tv.setText(res);
    }
}
