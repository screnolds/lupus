package com.test.mylupusproject.ui.home;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.test.mylupusproject.DbConnectionHelper;
import com.test.mylupusproject.HttpGetTask;
import com.test.mylupusproject.R;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class HomeFragment extends Fragment {

    //private HomeViewModel homeViewModel;
    Connection connect;
    String ConnectionResult="";
    @SuppressLint("NewApi")
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        //homeViewModel = new ViewModelProvider(this).get(HomeViewModel.class);
        View root = inflater.inflate(R.layout.fragment_home, container, false);
        final TextView textView = root.findViewById(R.id.pain_type);
        //GetTextFromSQL(textView);
        new HttpGetTask("https://us-west4-mylupusproject.cloudfunctions.net/pain?date=today",textView).execute();
//        homeViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
//            @Override
//            public void onChanged(@Nullable String s) {
//                textView.setText(s);
//            }
//        });
        return root;
    }

//    public void GetTextFromSQL(TextView tv)
//    {
//        try {
//            DbConnectionHelper dbConnectionHelper = new DbConnectionHelper();
//            connect = dbConnectionHelper.connectionclass();
//            if (connect!=null) {
//                String query = "Select Pain_Type from dbo.v_pain_dates where date = '06/17/2023'";
//                Statement st = connect.createStatement();
//                ResultSet rs = st.executeQuery(query);
//
//                while (rs.next()) {
//                    tv.setText(rs.getString(1));
//                }
//            } else {
//                tv.setText("DB CONNECTION ERROR");
//            }
//
//        } catch (SQLException throwables) {
//            throwables.printStackTrace();
//        }
//    }
}